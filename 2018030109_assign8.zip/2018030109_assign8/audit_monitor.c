#define _XOPEN_SOURCE 700 // Required for strptime

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <limits.h>
#include <time.h>
#include <stdbool.h>

#define MAX_LOGS 2000
#define MAX_PATH 4096
#define TIME_WINDOW 1200 // 20 minutes in seconds 

/* Structure to hold a log entry */
typedef struct {
    int uid;
    int pid;
    char path[MAX_PATH];
    char time_str[30];
    time_t log_time; 
    int operation; // 0=Create, 1=Open, 2=Write, 3=Close
    int denied;
    char hash[65];
} LogEntry;

LogEntry entries[MAX_LOGS];
int log_count = 0;

/* Load logs from the audit log file */
void load_logs(FILE *fp) {
    char line[MAX_PATH + 300];
    log_count = 0;
    rewind(fp);

    while (fgets(line, sizeof(line), fp) && log_count < MAX_LOGS) {
        struct tm tm_struct = {0};
        
        // Tokenize by pipe
        char *token = strtok(line, "|");
        if (!token) continue;
        entries[log_count].uid = atoi(token);

        token = strtok(NULL, "|"); // PID
        if (token) entries[log_count].pid = atoi(token);

        token = strtok(NULL, "|"); // Path
        if (token) strcpy(entries[log_count].path, token);

        token = strtok(NULL, "|"); // Time String
        if (token) {
            strcpy(entries[log_count].time_str, token);
            // Parse UTC string back to time_t
            if (strptime(token, "%Y-%m-%d %H:%M:%S", &tm_struct) != NULL) {
                entries[log_count].log_time = timegm(&tm_struct);
            } else {
                entries[log_count].log_time = 0;
            }
        }

        token = strtok(NULL, "|"); // Operation
        if (token) entries[log_count].operation = atoi(token);

        token = strtok(NULL, "|"); // Denied
        if (token) entries[log_count].denied = atoi(token);

        token = strtok(NULL, "\n"); // Hash
        if (token) {
            token[strcspn(token, "\r")] = 0; 
            strcpy(entries[log_count].hash, token);
        }
        log_count++;
    }
}

/* Burst Activity Detector */
void detect_burst_activity(int threshold) {
    printf("[*] Analyzing for High-Volume File Creation (Threshold: %d in %ds)...\n", threshold, TIME_WINDOW);
    
    int file_creations = 0;
    bool flag = false;
    // Iterate through all log entries
    for (int i = 0; i < log_count; i++) {
        // We only care about successful CREATE operations (Op 0)
        if (entries[i].operation != 0 || entries[i].denied == 1) continue;

        int burst_counter = 0;
        time_t current_time = entries[i].log_time;
        
        // Look backwards in the log within the time window
        for (int j = i; j >= 0; j--) {
            // Check if the previous entry is also a successful CREATE
            if (entries[j].operation == 0 && entries[j].denied == 0) {
                double diff = difftime(current_time, entries[j].log_time);
                
                // If within the time window, increment the counter
                if (diff >= 0 && diff <= TIME_WINDOW) {
                    burst_counter++;
                } else if (diff > TIME_WINDOW) {
                    // Logs are chronological, so we can stop looking back once we exceed the window
                    break; 
                }
            }
            // If we have reached the threshold, stop counting
            if (burst_counter >= threshold) {
                flag = true;
            }

            if (burst_counter > file_creations) {
                file_creations = burst_counter;
            }
        }
    }

    if (flag) {
        printf("(!) ALERT: Burst creation detected! %d files were created!\n", file_creations);
    }
}

/* Encryption Workflow Detector */
void detect_encryption_workflow() {
    printf("\n[*] Analyzing for Encryption-Delete patterns...\n");
    
    for (int i = 0; i < log_count; i++) {
        // Look for the CREATION (Op 0) of a file ending in ".enc"
        if (entries[i].operation == 0 && strstr(entries[i].path, ".enc")) {
            
            // Reconstruct what the original filename would be (remove the last 4 chars)
            char original_path[MAX_PATH];
            size_t path_len = strlen(entries[i].path);
            if (path_len <= 4) continue; // Safety check

            strncpy(original_path, entries[i].path, path_len - 4);
            original_path[path_len - 4] = '\0';

            // Scan backwards for an OPEN (Op 1) of that original file by the SAME PID
            for (int j = i - 1; j >= 0; j--) {
                if (entries[j].pid == entries[i].pid &&          // Same Process
                    entries[j].operation == 1 &&                 // Open Operation
                    strcmp(entries[j].path, original_path) == 0) // Same Filename (without .enc)
                {
                    printf("(!) ALERT: Suspicious Encryption Pattern Detected!\n");
                    printf("\tPID %d opened: %s\n", entries[j].pid, entries[j].path);
                    printf("\tPID %d created: %s\n", entries[i].pid, entries[i].path);
                    
                    // Once we find the "Open" pair for this "Create", we can stop looking back for this specific file
                    break; 
                }
            }
        }
    }
}

/* Wrapper Function */
void detect_ransomware(FILE *log, int threshold) {
    load_logs(log);
    printf("--- Ransomware Detection Report ---\n");
    detect_burst_activity(threshold);
    detect_encryption_workflow();
}

/* List file modifications for a given file  */
void list_file_modifications(FILE *log, char *file_to_scan) {
    load_logs(log);
    int users[100], writes[100], user_count = 0;
    char distinct_hashes[100][65];
    int hash_count = 0;

    printf("--- Analysis for %s ---\n", file_to_scan);

    for (int i = 0; i < log_count; i++) {
        int match = 0;
        if (strcmp(entries[i].path, file_to_scan) == 0) match = 1;
        else if (strstr(entries[i].path, file_to_scan) != NULL) match = 1; 
        
        if (!match) continue;

        int u_idx = -1;
        for(int u=0; u<user_count; u++) if(users[u] == entries[i].uid) u_idx = u;
        if (u_idx == -1) { users[user_count] = entries[i].uid; writes[user_count] = 0; u_idx = user_count++; }
        
        if (entries[i].operation == 2 && entries[i].denied == 0) writes[u_idx]++;

        if (strcmp(entries[i].hash, "-") != 0) {
            int h_seen = 0;
            for(int h=0; h<hash_count; h++) if(strcmp(distinct_hashes[h], entries[i].hash) == 0) h_seen = 1;
            if (!h_seen) {
                strcpy(distinct_hashes[hash_count++], entries[i].hash);
            }
        }
    }

    int unique_mods = (hash_count > 0) ? hash_count - 1 : 0;
    printf("Unique modifications: %d\n", unique_mods);
    
    for(int k=0; k<user_count; k++) {
        printf("User %d: %d writes\n", users[k], writes[k]);
    }
}

/* List users with excessive unauthorized accesses */
void list_unauthorized_accesses(FILE *log) {
    load_logs(log);
    int printed_uids[100], printed_count = 0;
    for (int i = 0; i < log_count; i++) {
        int uid = entries[i].uid;
        int checked = 0;
        for(int k=0; k<printed_count; k++) if(printed_uids[k] == uid) checked = 1;
        if (checked) continue;
        char denied_paths[100][MAX_PATH];
        int distinct = 0;
        for (int j = 0; j < log_count; j++) {
            if (entries[j].uid == uid && entries[j].denied == 1) {
                int seen = 0;
                for(int p=0; p<distinct; p++) if(strcmp(denied_paths[p], entries[j].path) == 0) seen = 1;
                if (!seen) strcpy(denied_paths[distinct++], entries[j].path);
            }
        }
        if (distinct > 5) printf("Suspicious User UID: %d (Denied on %d distinct files)\n", uid, distinct);
        printed_uids[printed_count++] = uid;
    }
}

void usage(void) {
    // Update help text to show -r requires a value
    printf("usage: ./audit_monitor -i <file> | -s | -r <threshold>\n");
    exit(1);
}

int main(int argc, char *argv[]) {
    if (argc < 2) usage();
    
    FILE *log = fopen("access_audit.log", "r"); 
    if (!log) { 
        printf("Error: cannot open access_audit.log\n"); 
        return 1; 
    }

    int ch;
    while ((ch = getopt(argc, argv, "hi:sr:")) != -1) {
        switch (ch) {       
            case 'i': 
                list_file_modifications(log, optarg); 
                break;
            case 's': 
                list_unauthorized_accesses(log); 
                break;
            case 'r':
                int threshold = atoi(optarg);
                if (threshold <= 0) {
                    printf("Error: Threshold must be a positive integer.\n");
                    exit(1);
                }
                detect_ransomware(log, threshold); 
                break;
            default: 
                usage();
        }
    }

    fclose(log);
    return 0;
}