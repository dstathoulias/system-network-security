#!/bin/bash

# Invalid input, exit
if [ "$#" -lt 2 ]; then
    echo "Usage: $0 <target_directory> <option: create|select> [number_of_files]"
    echo "Example (Create): $0 /home/student/target create 10"
    echo "Example (Select): $0 /home/student/data select"
    exit 1
fi

TARGET_DIR=$1
COUNT=$3
OPTION=$2

# If the target directory does not exist, exit
if [ ! -d "$TARGET_DIR" ]; then
    echo "Error: Target directory '$TARGET_DIR' does not exist."
    exit 1
fi

# The assignment directory is reserved for source files
if [[ "$TARGET_DIR" == "/home/student/assignment" ]]; then
    echo "Error: You cannot write in this directory."
    exit 1
fi

if [ "$OPTION" == "create" ]; then
    # NUmber of files to create needs to be specified for the Create option
    if [ -z "$COUNT" ]; then
        echo "Error: You must provide a number of files to create."
        exit 1
    fi
    
    echo "Creating $COUNT files in $TARGET_DIR..."
    for ((i=1; i<=COUNT; i++)); do
        awk "BEGIN { print \"File $i\" > \"$TARGET_DIR/file_$i.txt\" }"
    done

# Encryption proccess already selects all files in the target directory
# There is no need to implement any selection logic here
elif [ "$OPTION" == "select" ]; then
    echo "Selecting existing files in $TARGET_DIR..."
    
else
    echo "Error: Invalid option '$OPTION'. Use 'create' or 'select'."
    exit 1
fi

echo "Starting encryption routine..."

for file in "$TARGET_DIR"/*; do
    # If file is already encrypted, skip it
    if [[ "$file" == *.enc ]]; then
        continue
    fi

    # If target directory is /data then dlete the original files after encryption
    if [[ "$TARGET_DIR" == "/home/student/data" ]]; then
        # Encrypt the file using OpenSSL
        if openssl enc -aes-256-cbc -salt -in "$file" -out "${file}.enc" -k "password" -pbkdf2; then
            # Delete the original file only if encryption succeeded
            rm "$file"
            echo "Encrypted and deleted: $file"
        else
            echo "Encryption failed for $file. Original not deleted."
        fi
        
    # If target directory is /target then keep the original files for testing purposes
    else
        openssl enc -aes-256-cbc -salt -in "$file" -out "${file}.enc" -k "password" -pbkdf2
        echo "Encrypted: $file"
    fi
done