**Assignment 6: iptables Ad-Blocker Tool - README**
Author Information
- Author: ΔΗΜΗΤΡΗΣ ΣΤΑΘΟΥΛΙΑΣ
- AM: 2018030109
- Group Number: 36
- Institution: Technical University of Crete
- Department: School of Electrical & Computer Engineering
- Course: Ασφάλεια Συστημάτων και Υπηρεσιών
- Date: 19/12/2025
- Instructor: ΣΩΤΗΡΙΟΣ ΙΩΑΝΝΙΔΗΣ

**Tool Description**
The tool implemented is a bash script that uses the Linux iptables utility to configure the kernel's packet filters serving the puprose of an ad-blocker. Adding domain names/IP addresses in the config file, we can block any inbound/outbound traffic by adding an iptables rule to REJECT them. The tool also allows exporting the current rules to the IPv4 and IPv6 respective files, importing rules from those files, reseting the current ruleset to the default ACCEPT ALL protocol and listing the current rules in effect.

**Question**
After configuring the firewall rules, test your script by visiting your favorite websites without any other adblocking mechanism (e.g., adblock browser extensions). Can you see ads? Do they load? Some ads persist, why?

**Answer**
After thoroughly testing the tool, it is evident that it does serve the purpose of an ad-blocker, but also holds some major limitations. The most important of those is its lack of reliability. While we have successfully filtered all the major ad distribution IP addresses and domains, some ads persist due to multiple reasons. Firstly, in order for an ad-block tool to be reliable, it requires constant updating of the known ad distributors list due to them using randomized or frequently changed subdomains. Also, some platforms, like youtube and facebook, use their own domains to serve ads to their users making it impossible, using the iptables utility, to filter the ads without restricting access to the entire website. Finally, another more obscure reason is DNS caching. If the browser has already cached the IP address intended to be blocked before the rules were applied, the filters are able to be bypassed allowing the connection until the cache expires.

**Usage**
- chmod +x firewall.sh : makes the script executable
- sudo ./firewall.sh -config : parses config.txt file and adds REJECT rules for the resolved IP addresses
- sudo ./firewall.sh -save : exports the current rules to rulesV4 and rulesV6 files
- sudo ./firewall.sh -load : imports rules from rulesV4 and rulesV6 files
- sudo ./firewall.sh -list : lists all current rules in effect
- sudo ./firewall.sh -reset : removes all current rules and accepts all traffic
- sudo ./firewall.sh -help : displays tool information