#!/bin/bash
# You are NOT allowed to change the files' names!
config="config.txt"
rulesV4="rulesV4"
rulesV6="rulesV6"

function firewall() {
    if [ "$EUID" -ne 0 ]; then
        printf "Please run as root.\n"
        exit 1
    fi


    if [ "$1" = "-config"  ]; then
        # Configure adblock rules based on domain names and IPs of $config file

        # First, reset all current rules to avoid duplicates
        # -F option deletes all active rules in all chains
        iptables -F
        ip6tables -F
        
        # Iterate over config file and process IP's line by line
        while read -r line || [ -n "$line" ]; do

            # Skip empty lines and comments
            if [[ -z "$line" || "$line" =~ ^# ]]; then
                continue
            fi 

            # Check if config file entry is IPv4 or IPv6 address
            # If yes, no need to process -> add rule to REJECT the entry directly

            # Config file entry resembles IPv4 address 
            # Checks for 4 numbers seperated by a dot (xxx.xxx.xxx.xxx)
            if [[ "$line" =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}$ ]]; then
                iptables -A INPUT -s "$line" -j REJECT  # Add INPUT REJECT rule
                iptables -A OUTPUT -d "$line" -j REJECT # Add OUTPUT REJECT rule

            # Config file entry resembles IPv6 address
            # Checks if entry contains colons (xxxx:xxxx:xxxx:xxxx)
            elif [[ "$line" =~ .*:.* ]]; then
                ip6tables -A INPUT -s "$line" -j REJECT  # Add INPUT REJECT rule
                ip6tables -A OUTPUT -d "$line" -j REJECT # Add OUTPUT REJECT rule

            # If entry does not resemble an IPv4 or IPv6 address
            # we assume it is a domain name
            else
                # Executing multiple queries for the domain parsing can be computationally intense
                # We use subshells to execute the queries in the background for improved performance
                (
                    # Query the DNS for type A (IPv4) addresses
                    # The host output is the resolved query results formated as:
                    # 'domain name' has address xxx.xxx.xxx.xxx
                    # A domain can have multiple IP addresses 
                    # so we extract the resolved IPv4 addresses ($4) from the output
                    ipv4=$(host -t A "$line" | awk '/has address/ { print $4 }')
                    
                    # For every resolved IPv4 address we add a new REJECT rule
                    for ip in $ipv4; do
                        iptables -A INPUT -s "$ip" -j REJECT  # Add INPUT REJECT rule
                        iptables -A OUTPUT -d "$ip" -j REJECT # Add OUTPUT REJECT rule
                    done
                ) &

                (
                    # Query the DNS for type AAAA (IPv6) addresses
                    # The host output is the resolved query results formated as:
                    # 'domain name' has IPv6 address xxxx:xxxx:xxxx:xxxx:xxxx
                    # A domain can have multiple IP addresses 
                    # so we extract the resolved IPv6 addresses ($5) from the output
                    ipv6=$(host -t AAAA "$line" | awk '/has IPv6 address/ { print $5 }')

                    # For every resolved IPv6 address we add a new REJECT rule
                    for ip in $ipv6; do
                        ip6tables -A INPUT -s "$ip" -j REJECT  # Add INPUT REJECT rule
                        ip6tables -A OUTPUT -d "$ip" -j REJECT # Add OUTPUT REJECT rule
                    done
                ) &
            fi

        done < "$config"
        wait    # Wait for all background queries to finish 
        printf "Adblock rules configured from %s.\n" "$config"
        true

        
    elif [ "$1" = "-save"  ]; then
        # Save rules to $rulesV4/$rulesV6 files
        iptables-save > "$rulesV4"
        ip6tables-save > "$rulesV6"
        printf "Rules saved to %s and %s.\n" "$rulesV4" "$rulesV6"
        true
        

    elif [ "$1" = "-load"  ]; then
        # Load rules from $rulesV4/$rulesV6 files
        iptables-restore < "$rulesV4"
        ip6tables-restore < "$rulesV6"
        printf "Rules loaded from %s and %s.\n" "$rulesV4" "$rulesV6"
        true

        
    elif [ "$1" = "-reset"  ]; then
        # Flush all rules and delete user-defined chains

        # Flush all active rules in all chains (user-defined chains included)
        iptables -F 
        ip6tables -F

        # Delete all empty chains
        # All user-defined chains are now empty -> Delete them
        # Built-in chains (INPUT, OUTPUT, FORWARD etc.) are not deleted
        iptables -X
        ip6tables -X  

        # Allow all Ad traffic
        # This is done by accepting the built-in chains INPUT, OUTPUT
        iptables -P INPUT ACCEPT    # Accept input chain (inbound ad traffic)
        ip6tables -P INPUT ACCEPT

        iptables -P OUTPUT ACCEPT   # Accept output chain (outbound ad traffic)
        ip6tables -P OUTPUT ACCEPT

        printf "Adblock rules have been reset. All ads are accepted.\n"
        true

        
    elif [ "$1" = "-list"  ]; then
        # List IPv4/IPv6 current rules
        printf "IPv4 Rules:\n"
        iptables -L -n -v
        printf "\nIPv6 Rules:\n"
        ip6tables -L -n -v
        true

        
    elif [ "$1" = "-help"  ]; then
        printf "This script is responsible for creating a simple firewall mechanism. It rejects connections from specific domain names or IP addresses using iptables/ip6tables.\n\n"
        printf "Usage: $0  [OPTION]\n\n"
        printf "Options:\n\n"
        printf "  -config\t  Configure adblock rules based on the domain names and IPs of '$config' file.\n"
        printf "  -save\t\t  Save rules to '$rulesV4' and '$rulesV6'  files.\n"
        printf "  -load\t\t  Load rules from '$rulesV4' and '$rulesV6' files.\n"
        printf "  -list\t\t  List current rules for IPv4 and IPv6.\n"
        printf "  -reset\t  Reset rules to default settings (i.e. accept all).\n"
        printf "  -help\t\t  Display this help and exit.\n"
        exit 0
    else
        printf "Wrong argument. Exiting...\n"
        exit 1
    fi
}

firewall $1
exit 0