#!/bin/bash
echo "[*] Compiling Greeter..."
make Greeter

# Generate the payload
echo "[*] Generating payload..."
python3 greeter_exploit.py

# Execute the exploit
echo "[*] Injecting payload..."
(cat greeter_payload; cat) | ./Greeter