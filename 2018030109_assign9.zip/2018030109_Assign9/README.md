**Assignment 9: Buffer Overflow Exploitation - README**
Author Information
- Author: ΔΗΜΗΤΡΗΣ ΣΤΑΘΟΥΛΙΑΣ
- AM: 2018030109
- Group Number: 36
- Institution: Technical University of Crete
- Department: School of Electrical & Computer Engineering
- Course: Ασφάλεια Συστημάτων και Υπηρεσιών
- Date: 18/1/2026
- Instructor: ΣΩΤΗΡΙΟΣ ΙΩΑΝΝΙΔΗΣ

**Assignment Description**
The purpose of this assignment is the exploitation of three variants of a Greeter program with varying protection levels. The goal is to take advantage of a buffer overflow vulnerability by injecting a payload that spawns a shell terminal, allowing the attacker to execute shell commands on the user's machine.

**Tool Execution Instructions**
To run the three exploit scripts execute the following commands:
1. make bash: this will make the bash scripts executable
2. execute the relevant command below for the respective Greeter variant:
    - ./greeter_bash.sh: execute and exploit the Greeter program
    - ./secGreeter_bash.sh: execute and exploit the secureGreeter program
    - ./secGreeterASLR_bash.sh: execute and exploit the secureGreeterASLR program

**Greeter Exploitation**
The first greeter program is the most unprotected variant with a static binary. To exploit that vulnerability, I first used GDB to determin the offset to the return address and the address of the name variable, which were later used to calculate the jump address needed for the payload injection. The payload then is constructed using pwntools shellcraft and the found offset and name address. Finally, the payload is saved to a file and injected in the name variale at execution while a cat command and a seperator to keep the generated shell terminal open for commands execution.

**secGreeter Exploitation**
The second program, SecGreeter, introduces Data Execution Prevention (DEP), making the stack non-executable. To bypass this, I utilized a "Return-to-Libc" attack, leveraging existing code within the standard C library instead of injecting new shellcode. I first disabled ASLR as required by the assignment, then used GDB to locate the system function, the exit function, and the string "/bin/sh" within libc. Using these, I constructed a payload that overflows the buffer and overwrites the return address to call system with "/bin/sh" as its argument. Finally, the injection attack is executed using the same method as the greeter exploit.

**secGreeterASLR Exploit**
The final program, SecGreeterASLR, is a 64-bit binary protected by both DEP and Address Space Layout Randomization (ASLR), which randomizes library locations on each run. To exploit this program, I first used pwntools to leak a libc address from the stack. By calculating the offset between this leak and the base of libc, the script determines the current addresses of system and "/bin/sh". I then constructed a ROP chain to inject the "/bin/sh" string into the correct register before calling system. This spawns an interactive shell terminal where shell commands can be executed.