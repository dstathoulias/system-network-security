#!/bin/bash

# Enable ASLR
echo "[*] Enabling ASLR..."
echo 2 | sudo tee /proc/sys/kernel/randomize_va_space

# Compile the binary
echo "[*] Compiling SecGreeterASLR..."
make secure_greeter_aslr

# Execute the exploit
echo "[*] Injecting payload..."
python3 secGreeterASLR_exploit.py